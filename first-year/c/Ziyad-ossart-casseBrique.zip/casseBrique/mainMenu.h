//
// Created by ziyad on 04/12/2023.
//

#ifndef MAINMENU_H
#define MAINMENU_H

#endif //MAINMENU_H

#include <SDL.h>
#include <SDL_image.h>
#include <SDL_ttf.h>

int menu(SDL_Renderer* renderer);
void optionsMenu(SDL_Renderer *renderer);