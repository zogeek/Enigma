#include <stdio.h>
#include "Pendu.h"

int main()
{
    Game();
    return 0;
}
