package bo;

public class Player {
    protected String name;
    protected String playerBoard;
    protected String attackBoard;

    public Player(String name) {
        this.name = name;
        this.playerBoard = new PlayerBoard();
        this.attackBoard = new AttackBoard();
    }
}